public class Receiver implements Runnable {
    private final int id;
    private final int numProcesses;
    private final Token token;

    public Receiver(int id, int numProcesses, Token token) {
        this.id = id;
        this.numProcesses = numProcesses;
        this.token = token;
    }

    @Override
    public void run() {
        while (true) {
            // Check if it's the receiver's turn to receive data
            if (token.getCurrentProcessId() == (id + 1) % numProcesses) {
                // Receive data
                String receivedData = token.getData();
                System.out.println("Receiver " + id + " received data: " + receivedData);

                // Process the received data

                // Pass the token to the next process
                token.passToken();
            }
        }
    }
}

