import java.util.ArrayList;
import java.util.List;

class Process {
    private int processId;
    private int clock;
    private boolean isCoordinator;

    public Process(int processId) {
        this.processId = processId;
        this.clock = 0;
        this.isCoordinator = false;
    }

    public int getProcessId() {
        return processId;
    }

    public int getClock() {
        return clock;
    }

    public void setClock(int clock) {
        this.clock = clock;
    }

    public boolean isCoordinator() {
        return isCoordinator;
    }

    public void setCoordinator(boolean coordinator) {
        isCoordinator = coordinator;
    }
}

class ClockSynchronization {
    private List<Process> processes;

    public ClockSynchronization(int numProcesses) {
        processes = new ArrayList<>();
        for (int i = 0; i < numProcesses; i++) {
            Process process = new Process(i);
            processes.add(process);
        }
    }

    public void runSynchronization() {
        // Select a random process as the coordinator
        int coordinatorIndex = (int) (Math.random() * processes.size());
        processes.get(coordinatorIndex).setCoordinator(true);

        // Set initial clock values for all processes
        for (Process process : processes) {
            process.setClock((int) (Math.random() * 10));
        }

        // Print initial clock values
        System.out.println("Initial clock values:");
        printClocks();

        // Synchronize clocks
        synchronizeClocks();

        // Print final clock values
        System.out.println("Final clock values:");
        printClocks();
    }

    private void synchronizeClocks() {
        // Coordinator collects clock values from all other processes
        int totalClockValue = 0;
        for (Process process : processes) {
            if (!process.isCoordinator()) {
                totalClockValue += process.getClock();
            }
        }

        // Calculate the new clock value for all processes
        int newClockValue = totalClockValue / (processes.size() - 1);
        for (Process process : processes) {
            if (!process.isCoordinator()) {
                process.setClock(newClockValue);
            }
        }
    }

    private void printClocks() {
        for (Process process : processes) {
            System.out.println("Process " + process.getProcessId() + ": " + process.getClock());
        }
    }
}

