import java.util.concurrent.Semaphore;

public class Token {
    private int currentProcessId;
    private Semaphore tokenSemaphore;

    public Token(int numProcesses) {
        currentProcessId = 0;
        tokenSemaphore = new Semaphore(1);
    }

    public void requestToken() {
        try {
            tokenSemaphore.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void releaseToken() {
        tokenSemaphore.release();
    }

    public int getCurrentProcessId() {
        return currentProcessId;
    }

    public void setCurrentProcessId(int processId) {
        currentProcessId = processId;
    }
}

