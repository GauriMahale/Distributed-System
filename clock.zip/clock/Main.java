public class Main {
    public static void main(String[] args) {
        int numProcesses = 5;

        ClockSynchronization clockSync = new ClockSynchronization(numProcesses);
        clockSync.runSynchronization();
    }
}

