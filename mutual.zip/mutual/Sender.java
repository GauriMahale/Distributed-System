public class Sender implements Runnable {
    private int processId;
    private int numProcesses;
    private Token token;
    private String data;

    public Sender(int processId, int numProcesses, Token token, String data) {
        this.processId = processId;
        this.numProcesses = numProcesses;
        this.token = token;
        this.data = data;
    }

    public void run() {
        System.out.println("Process " + processId + " is doing some work before requesting the token: " + data);
        token.requestToken();
        System.out.println("Process " + processId + " has received the Token");
        System.out.println("Process " + processId + " is in the critical section: " + data);
        token.releaseToken();
        System.out.println("Process " + processId + " is doing some work after releasing the token: " + data);
    }
}

