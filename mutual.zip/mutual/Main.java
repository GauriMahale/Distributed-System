public class Main {
    public static void main(String[] args) {
        int numProcesses = 5;

        Token token = new Token(numProcesses);

        // Create and start sender threads
        Thread[] senderThreads = new Thread[numProcesses];
        for (int i = 0; i < numProcesses; i++) {
            Sender sender = new Sender(i, numProcesses, token, "Data from Sender " + i);
            senderThreads[i] = new Thread(sender);
            senderThreads[i].start();
        }

        // Wait for all sender threads to complete
        try {
            for (int i = 0; i < numProcesses; i++) {
                senderThreads[i].join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

